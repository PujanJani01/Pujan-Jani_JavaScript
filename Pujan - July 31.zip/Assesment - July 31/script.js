let myamount = document.getElementById('amount');
const promos = ['OFF25','OFF50','OFF75'];
let promoinput = document.getElementsByClassName('promoinput')[0];
let checkbtn = document.querySelector('.checkpromo');
let promomessage = document.querySelector('.promomessage')
let summaryAmount = document.getElementById('summaryamount');
let totalAmount = document.getElementById('totalamount');
let totalPay = document.getElementById('totalpay');


myamount.addEventListener('change',() =>{
    let amountAfterGst = Number(myamount.value) + (Number(myamount.value) * 18/100);
    summaryAmount.innerText = 'Rs.'+ amountAfterGst;
    totalAmount.innerText = 'Rs.'+ amountAfterGst;
    totalpay.innerText = 'Rs.'+amountAfterGst;
})

promoinput.addEventListener('change', () =>{
     checkbtn.removeAttribute('disabled');
 })

 checkbtn.addEventListener('click',() =>{
    if(Number(myamount.value) > 500){
        if(promoinput.value == 'OFF25'){
            if(promos.includes(promoinput.value)){
                promomessage.innerText = promoinput.value + ' Applied';
                promomessage.style.color = 'green';
                totalAmount.innerText = 'Rs.'+ amountAfterGst - amountAfterGst*25/100;
            }
            else{
                promomessage.innerText = "Invalid promocode";
                promomessage.style.color = 'red';
            }
        } 
    }
 })